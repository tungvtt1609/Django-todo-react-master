# .wav to .csv
Simple converting .wav file to .csv file with python.
Inspired by [HadrienG2] https://github.com/HadrienG2/wav-csv-conversion

This Project provide converting process wav file to csv file for data analysis or processing.


# wav2csv How use
0. Need scipy and pandas [pip install scipy],[pip install pandas] and python over 3.6
1. Input wav file name with its format [sample.wav]
2. After it finish load it begin to split channels and save. (If the audio type is mono it returns one csv file. If stereo it returns two Right and Left)
3. Done!

# And...
sample wav file comes from BBC fx sound - http://bbcsfx.acropolis.org.uk/
Any commits are welcomed
